﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2024_04_24_Verifica {
    public class Domanda {
        public int Gruppo { get; set; }
        public int Numero { get; set; }
        public int Variante { get; set; }
        public string Immagine { get; set; }
        public string Quesito { get; set; }
        public bool Risposta { get; set; }

    }
}
