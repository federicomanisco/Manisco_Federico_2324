﻿int n_biglietti;

Console.Write("Inserire il numero di biglietti da comprare: ");
n_biglietti = int.Parse(Console.ReadLine());

Console.WriteLine("Il costo totale è di: " + n_biglietti * 5 + "euro.");