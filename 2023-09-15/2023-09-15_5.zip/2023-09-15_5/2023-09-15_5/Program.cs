﻿float x;

Console.Write("Inserisci il valore della x: ");
x = float.Parse(Console.ReadLine());    

Console.WriteLine($"La y vale {(2 * x) + 3}");