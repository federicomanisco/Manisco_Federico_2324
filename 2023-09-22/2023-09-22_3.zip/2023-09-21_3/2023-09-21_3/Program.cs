﻿float lato;

Console.Write("Inserisci il lato del pentagono: ");
lato = float.Parse(Console.ReadLine());

Console.Write($"Il perimetro è di {lato * 5}");